package com.example.meuprimeirapp

import com.example.meuprimeirapp.R
import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Variáveis para armazenar os cálculos
    private var valor1: Double = 0.0
    private var operacao: String = ""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Referência do Display
        val tvDisplay = findViewById<TextView>(R.id.tvDisplay)

        // Referências dos Botões
        val btnCE = findViewById<Button>(R.id.btnCE)
        val btn0 = findViewById<Button>(R.id.btn0)
        val btn1 = findViewById<Button>(R.id.btn1)
        val btn2 = findViewById<Button>(R.id.btn2)
        val btn3 = findViewById<Button>(R.id.btn3)
        val btn4 = findViewById<Button>(R.id.btn4)
        val btn5 = findViewById<Button>(R.id.btn5)
        val btn6 = findViewById<Button>(R.id.btn6)
        val btn7 = findViewById<Button>(R.id.btn7)
        val btn8 = findViewById<Button>(R.id.btn8)
        val btn9 = findViewById<Button>(R.id.btn9)

        val btnAC = findViewById<Button>(R.id.btnAC)
        val btnSomar = findViewById<Button>(R.id.btnSomar)
        val btnSubtrair = findViewById<Button>(R.id.btnSubtrair)
        val btnMulti = findViewById<Button>(R.id.btnMulti)
        val btnIgual = findViewById<Button>(R.id.btnIgual) // Certifique-se que este ID existe no XML

        // --- Lógica dos Números ---
        val listaBotoes = listOf(btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9)

        listaBotoes.forEach { botao ->
            botao.setOnClickListener {
                tvDisplay.append(botao.text)
            }
        }

        // --- Lógica das Operações ---
        val configurarOperacao = { op: String ->
            if (tvDisplay.text.isNotEmpty()) {
                valor1 = tvDisplay.text.toString().toDouble()
                operacao = op
                tvDisplay.text = "" // Limpa para o próximo número
            }
        }
        btnCE.setOnClickListener {
            // This clears the display text
            tvDisplay.text = ""
            // If you have a variable storing the current number, reset it here too
            // currentInput = ""
        }


        btnSomar.setOnClickListener { configurarOperacao("+") }
        btnSubtrair.setOnClickListener { configurarOperacao("-") }
        btnMulti.setOnClickListener { configurarOperacao("*") }

        // --- Botão de Divisão (/) ---
        btnAC.setOnClickListener {
            configurarOperacao("/")
        }

        // --- Botão Igual (=) ---
        btnIgual.setOnClickListener {
            if (tvDisplay.text.isNotEmpty() && operacao.isNotEmpty()) {
                val valor2 = tvDisplay.text.toString().toDouble()
                val resultado = when (operacao) {
                    "+" -> valor1 + valor2
                    "-" -> valor1 - valor2
                    "*" -> valor1 * valor2
                    "/" -> if (valor2 != 0.0) valor1 / valor2 else 0.0 // Add this line
                    else -> 0.0
                }

                // Exibe o resultado e reseta a operação
                tvDisplay.text = resultado.toString()
                operacao = ""
            }
        }
    }
}